const { json } = require('express/lib/response');
const Hospital = require('../Models/hospital');
const hospital = require('../Models/hospital');
//Get all hospitals
//GET /api/v1/hospitals
//Public
exports.getHospitals= async (req,res,next)=>{
    try{
        const hospitals = await Hospital.find();
        res.status(200).json({success:true,count:hospitals.length, data:hospitals});
    }catch (err){
        res.status(400).json({success:false});
    }
   
};

//Get single hospital
//GET /api/v1/hospitals/:id
//Public
exports.getHospital= async (req,res,next)=>{
    try{
        const hospital = await Hospital.findById(req.params.id);

        if(!hospital){
            return res.status(400).json({success:false});
        }

        res.status(200).json({success:true,data:hospital});
    } catch(err){
        res.status(400).json({success:false});
    }
    
};

//Create new hospital
//POST /api/v1/hospitals
//Private
exports.createHospital= async (req,res,next)=>{
    const hospital = await Hospital.create(req.body);
    res.status(201).json({success:true, data:hospital});
};

//Update single hospital
//PUT /api/v1/hospitals/:id
//Private
exports.updateHospital= async (req,res,next)=>{
    try{
        const hospital = await Hospital.findByIdAndUpdate(req.params.id, req.body,{
        new: true,
        runValidators:true
    });

    if(!hospital){
        return res.status(400).json({success:false});
    }

        res.status(200).json({success:true, data:hospital});

    }catch(err){
        res.status(400).json({success:false});
    }
    
};

//Delete single hospital
//DELETE /api/v1/hospitals/:id
//Private
exports.deleteHospital= async (req,res,next)=>{
    try{
        const hospital = await Hospital.findByIdAndDelete(req.params.id, req.body);

    if(!hospital){
        return res.status(400).json({success:false});
    }

        res.status(200).json({success:true, data:{}});

    }catch(err){
        res.status(400).json({success:false});
    }
};